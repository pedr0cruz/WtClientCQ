#ifndef RECORDSETS_CTRL_H
#define RECORDSETS_CTRL_H

#include <Wt/WObject>
#include <Wt/WTabWidget>
#include <Wt/WTemplateFormView>

#include "ObserverGoF.h"

class RecordSetsModel;
class RecordSetsView;
class RecordSetController;

///	Esta clase funciona como contenedor para todas las tuplas MVC. Adem�s, 
/// incluye un puntero al Widget contenedor con las pesta�as. Cada tupla
/// MVC funciona de manera independiente con su propio controlador, modelo
/// y vista.
class RecordSetsController : public Wt::WObject, public SubjectGoF
{
public:
	/// Constructor
    //RecordSetsController(Wt::WContainerWidget* tabWidgetParent);
    RecordSetsController(const std::string & parent);

    /// Crea la vista
    Wt::WWidget* createView(Wt::WContainerWidget* rssParentContainer);

    /// Crea un nuevo controlador para una nueva pesta�a
    RecordSetController* newController(const string & name);

    /// Evento que ocurre al cambiar la pesta�a activa
	void tabChanged(string s);
	//EventSignal<WScrollEvent>& scrolled();

	/// Slot para seleccion de nuevo item
	//string selectedTab() { return selectedTab_; }
    //int currentTabIndex() { return currentTabIndex_; }

	/// Destructor
	~RecordSetsController();

protected:
    /// Modelo asociado a este controlador
    RecordSetsModel* model_;
    /// Vista asociada a este controlador
    RecordSetsView* view_;
    Wt::WTabWidget* recTabWidget_;
    Wt::WContainerWidget* recTabWidgetContainer_;

    /// Mapa de indices (enteros) a controladores (uno por pesta�a)
    typedef std::map<int, RecordSetController*> ControllersMap;
    ControllersMap controllersMap_;
};

#endif /// RECORDSETS_CTRL_H
